`define assert(ast_name,clk_info,reset_info,property_info) \
ast_name``_ast:assert property(@(posedge clk_info) disable iff(!reset_info)property_info)

`define assume(asm_name,clk_info,reset_info,property_info) \
asm_name``_asm:assume property(@(posedge clk_info) disable iff(!reset_info)property_info)

`define cover(cov_name,clk_info,reset_info,property_info) \
cov_name``_cov:cover property(@(posedge clk_info) disable iff(!reset_info)property_info)

