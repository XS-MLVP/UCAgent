#---step1:read in the design -------------------
read_design -top counter -sysv -mfcu  ../sva_lib/sva_lib.sv \
         ../rtl/counter.v ../env/counter_checker.sv  

#---step2:define the clock and reset-------------
def_clk clk
def_rst rst_n -val 0

#---step3:configure the verification process------
add_cons -postreset rst_n -pinval 1'b1
set_opt -time 5
#---step4:start to prove ------------------------
rm_prop counter_checker_inst1.ast_coi_test
fanin -cover -list -disp

add_prop counter_checker_inst1.ast_coi_test
fanin -cover -list -disp
#---step5:show result and debug------------------
#ave_trace counter_checker_inst1.one_step_incremental_counter_ast








