`define COUNT_MAX 3'd5
`define INITIAL_VALUE 3'd0
module counter_checker(in,clk,rst_n,c_out,coi_test);
   input in,clk,rst_n;
   input [2:0]c_out;
   output     coi_test;
  
//1.the reset state of counter should be `INITIAL_VALUE;
//--------glue logic to set first clock flag---------   
   reg 	      first_clock_flag;
   always@(posedge clk or negedge rst_n)
     if(!rst_n)
       first_clock_flag<=1'd0;
     else
       first_clock_flag<=1'd1;
       
   property couter_init_state ;
      @(posedge clk) (first_clock_flag==1'b0) |-> c_out==`INITIAL_VALUE;
   endproperty

//2.the counter increase step is 1;
   
   property one_step_incremental_counter;
      @(posedge clk) (c_out!=`INITIAL_VALUE) |-> c_out==($past(c_out)+1);
   endproperty

//3.the couter value should <= `COUNT_MAX   
   sequence a_lellorequa_b(a,b);
      a<=b;
   endsequence // a_lellorequa_b
   
   property counter_maxvalue;
      @(posedge clk) a_lellorequa_b(c_out,`COUNT_MAX); 
   endproperty


//4.ensure each value between `INITIAL_VALUE and `COUNT_MAX should be covered;
//   wire [2:0] cover_value;
//   asm_cover_value:assume property(@(posedge clk) $stable(cover_value) && (cover_value>=`INITIAL_VALUE)&&(cover_value<=4/*`COUNT_MAX */) );   
   property counter_cover_parameter_value(a);
      @(posedge clk) c_out==a;
   endproperty

      
//declare properties as assertions   
   ast_couter_init_state : assert property (couter_init_state);
   `assert (one_step_incremental_counter,clk,rst_n,one_step_incremental_counter);
   ast_counter_maxvalue: assert property(counter_maxvalue);

   genvar     i;
   generate 
      for(i=0;i<=`COUNT_MAX;i++) begin
	cov_counter_covered_all_value:cover property(counter_cover_parameter_value(i) );
      end
   endgenerate


   ast_coi_test:assert property(@(posedge clk )##1 coi_test==$past(in) );
   
     
endmodule // counter_checker

bind counter counter_checker counter_checker_inst1(.*);
